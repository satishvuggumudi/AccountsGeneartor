﻿using System;
using System.Linq;

namespace AccountNumberGenerator
{
    public class RandomAccountNumber
    {
        public int[] SortCodeAccountNumberArray(string sortCode, string accountNumber)
        {
            var sortCodeAccountNumber = (sortCode + accountNumber).ToCharArray();
            var intSortCodeAccountNumberArray = sortCodeAccountNumber.Select(x => int.Parse(x.ToString())).ToArray();
            return intSortCodeAccountNumberArray;
        }

        public string GenerateAccountNumber()
        {
            var accountNumber = DateTime.UtcNow.Ticks.ToString();
            accountNumber = accountNumber.Substring(accountNumber.Length - 8);
            return accountNumber;
        }

    }
}
