﻿using ExcelDataReader;
using System.Data;
using System.IO;
using System.Reflection;

namespace AccountNumberGenerator
{
    public class ReadExcelData
    {
        private readonly string _fileName;
        public ReadExcelData(string fileName)
        {
            _fileName = fileName;
        }

        public DataTable ExcelToDataTableUsingExcelDataReader(string sheetName)
        {
             var filePath = GetResourceFilePath(_fileName);
            
            DataTable sheetDataTable = null;
            FileStream stream = null;
            IExcelDataReader excelReader = null;
            using (stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

                //Check file extension to adjust the reader to the excel file type
                if (Path.GetExtension(filePath).Equals(".xls"))
                {
                    excelReader = ExcelReaderFactory.CreateBinaryReader(stream);
                }
                else if (Path.GetExtension(filePath).Equals(".xlsx"))
                {
                    excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                    //excelReader = ExcelReaderFactory.CreateReader(stream);

                    var conf = new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = a => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    };
                }

                //DataSet - The result of each spreadsheet will be created in the dataTable.Tables
                DataSet result = excelReader?.AsDataSet();
                sheetDataTable = result?.Tables[sheetName];

            }
            return sheetDataTable;
        }


        public static string GetResourceFilePath(string fileName)
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                "\\Resources\\" + fileName;
        }
    }
}
