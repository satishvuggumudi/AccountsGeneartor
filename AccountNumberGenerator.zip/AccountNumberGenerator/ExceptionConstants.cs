﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountNumberGenerator
{
    public class ExceptionConstants
    {
        public const int ExceptionOne = 1;
        public const int ExceptionTwo = 2;
        public const int ExceptionThree = 3;
        public const int ExceptionFour = 4;
        public const int ExceptionFive = 5;
        public const int ExceptionSix = 6;
        public const int ExceptionSeven = 7;
        public const int ExceptionEight = 8;
        public const int ExceptionNine = 9;
        public const int ExceptionTen = 10;
        public const int ExceptionEleven = 11;
        public const int ExceptionTwelve = 12;
        public const int ExceptionThirteen = 13;
        public const int ExceptionFourteen = 14;
        public const int ExceptionZero = 0;
    }
}
