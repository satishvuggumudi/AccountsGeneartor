﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;

namespace AccountNumberGenerator
{
    class Program
    {

        static ReadModulusWeightTable readModulusWeightTable = new ReadModulusWeightTable();
        static RandomAccountNumber randomAccountNumber = new RandomAccountNumber();
        static GenerateAccountNumber generateAccountNumber = new GenerateAccountNumber();
        static Account account = new Account();
        static string ModcalculationValue = null;
        static int[] Weight = null;


        static void Main(string[] args)
        {
            Console.WriteLine("Genearte Valid Account Numbers");
            Console.WriteLine("----------------");
            Console.WriteLine("Please Enter a valid SortCode");
            Console.WriteLine("----------------");
            account.SortCode = Console.ReadLine();

            GetValidAccountNumber();

            //var toGenerate = Convert.ToInt32(Console.ReadLine()); 
            Console.WriteLine("----------------");
         }

        public static void GetValidAccountNumber()
        {
            // account.SortCode = sortCode;

            if (readModulusWeightTable.ModCalculation(account.SortCode).Count == 0)
            {
                Console.WriteLine("Invalid SortCode: Sortcode doesn't exists in EISCD Table");
            }
            else
            {
                account.SortCode = readModulusWeightTable.SubstituteSortCodeWith(account.SortCode).ToString();
                var result = readModulusWeightTable.ModCalculation(account.SortCode);
                ModcalculationValue = result.First().ModulusCheckType;
                Weight = result.First().Weight;

                Console.WriteLine("----------------");
                Console.WriteLine("Please specify the number of account to generate");
                Console.WriteLine("----------------");
                var toGenerate = Convert.ToInt32(Console.ReadLine());

                for (var i = 1; i <= toGenerate; i++)
                {
                    account.AccountNumber = generateAccountNumber.GenerateValidAccountNumber(account.SortCode, ModcalculationValue, Weight);
                    Console.WriteLine("Valid Account Number for " + account.SortCode + " : " + account.AccountNumber);
                }
            }
            
        }


    }
}
