﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AccountNumberGenerator
{
    public class GenerateAccountNumber
    {
        string accountNumber;
        RandomAccountNumber randomAccountNumber = new RandomAccountNumber();
        ReadModulusWeightTable readModulusWeightTable = new ReadModulusWeightTable();
        ValidWithModCheck modCheck = new ValidWithModCheck();


        public string GenerateValidAccountNumber(string sortCode, string bmdCalculationValue, int[] weight)
        {
            var result = readModulusWeightTable.ModCalculation(sortCode);

            switch (result.LastOrDefault().ExceptionValue)
            {
                case ExceptionConstants.ExceptionZero:
                    {
                        WithNoException(sortCode, bmdCalculationValue, result, false);

                        break;
                    }
                case ExceptionConstants.ExceptionOne:
                    {
                        WithExceptionOne(sortCode, bmdCalculationValue, result, false);

                        break;
                    }
                case ExceptionConstants.ExceptionThree:
                    {
                        WithExceptionThree(sortCode, result, false);

                        break;
                    }
                case ExceptionConstants.ExceptionFour:
                    {
                        WithExceptionFour(sortCode, result, false);

                        break;
                    }
                default:
                    {
                        if (result.FirstOrDefault().ExceptionValue == ExceptionConstants.ExceptionTwelve || result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionThirteen)
                        {
                            WithExceptionTwelveOrThirteen(sortCode, result, false);
                        }
                        else if (result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionSix)
                        {
                            WithExceptionSix(sortCode, result, false);
                        }
                        else if (result.FirstOrDefault().ExceptionValue == ExceptionConstants.ExceptionTwo || result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionNine)
                        {
                            WithExceptionTwoOrNine(sortCode, result, false);
                        }

                        else if (result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionSeven)
                        {
                            WithExceptionSeven(sortCode, result, false);
                        }

                        else if (result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionTen || result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionEleven)
                        {
                            WithExceptionTenOrEleven(sortCode, result, false);
                        }

                        else if (result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionFourteen)
                        {
                            WithExceptionFourteen(sortCode, result, false);
                        }

                        else if (result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionEleven)
                        {
                            WithExceptionFive(sortCode, result, false);
                        }

                        else if (result.LastOrDefault().ExceptionValue == ExceptionConstants.ExceptionEight)
                        {
                            WithExceptionEight(result, false);
                        }

                        break;
                    }
            }

            return accountNumber;
        }

        private bool WithExceptionEight(List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                var subSortCode = "090126";
                accountNumber = randomAccountNumber.GenerateAccountNumber();

                isCheck = (modCheck.WithMod10(subSortCode, accountNumber, result.LastOrDefault().Weight)).IsValid;
            }
            Console.WriteLine("Account Number with Exception 8: " + accountNumber);
            return isCheck;
        }

        private bool WithExceptionFive(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                var substituteWith = readModulusWeightTable.SubstituteSortCodeWith(sortCode);
                var firstCheckRemainder = 0;
                var secondCheckRemainder = 0;
                var gValue = 0;
                var hValue = 0;
                //total = 0;
                accountNumber = randomAccountNumber.GenerateAccountNumber();
                gValue = Convert.ToInt32(accountNumber.Substring(6, 1));
                hValue = Convert.ToInt32(accountNumber.Substring(7, 1));

                bool validFirstCheck = false;
                var firstCheck = modCheck.WithMod11(substituteWith, accountNumber, result.FirstOrDefault().Weight);

                if (firstCheck.IsValid)
                {
                    firstCheckRemainder = firstCheck.Total % 11;
                    if (firstCheckRemainder == 0 && gValue == 0)
                    {
                        validFirstCheck = true;
                    }
                    else
                    {
                        validFirstCheck = (gValue == (11 - (firstCheck.Total % 11)));
                    }
                }
                if (validFirstCheck)
                {
                    var secondCheck = modCheck.WithDblal(substituteWith, accountNumber, result.LastOrDefault().Weight);
                    if (secondCheck.IsValid)
                    {
                        secondCheckRemainder = secondCheck.Total % 10;
                        if (secondCheckRemainder == 0 && hValue == 0)
                        {
                            isCheck = true;
                        }
                        else
                        {
                            isCheck = (hValue == (10 - (secondCheck.Total % 10)));
                        }
                    }
                }
            }

            return isCheck;
        }

        internal bool WithExceptionFourteen(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();

                isCheck = modCheck.WithMod11(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid;
                if (isCheck)
                {
                    isCheck = true;
                }
                else if (!isCheck)
                {
                    var eightDigitValue = accountNumber.Substring(7, 1);
                    if (eightDigitValue == "0" || eightDigitValue == "9" || eightDigitValue == "1")
                    {
                        var modifiedAccountNumber = accountNumber.Substring(0, 7);

                        accountNumber = "0" + modifiedAccountNumber;

                        if (modCheck.WithMod11(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                        {
                            isCheck = true;
                        }
                    }
                }
            }

            return isCheck;
        }

        internal bool WithExceptionTenOrEleven(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();

                var abValue = accountNumber.Substring(0, 1) + accountNumber.Substring(1, 1);
                var gValue = accountNumber.Substring(6, 1);

                if ((abValue == "09" || abValue == "99") && gValue == "9")
                {
                    int[] newWeight = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 8, 7, 10, 9, 3, 1 };

                    if (modCheck.WithMod11(sortCode, accountNumber, newWeight).IsValid)
                    {
                        isCheck = true;
                    }
                }
                else
                {

                    if (modCheck.WithMod11(sortCode, accountNumber, result.FirstOrDefault().Weight).IsValid)
                    {
                        isCheck = true;
                    }
                    else
                    {
                        if (modCheck.WithMod11(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                        {
                            isCheck = true;
                        }
                    }
                }
            }

            return isCheck;
        }

        internal bool WithExceptionSeven(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();
                var checkDigitG = Convert.ToInt32(accountNumber.Substring(6, 1));

                if (checkDigitG == 9)
                {
                    int[] newWeight = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 8, 7, 10, 9, 3, 1 };

                    if (modCheck.WithMod11(sortCode, accountNumber, newWeight).IsValid)
                    {
                        isCheck = true;
                    }

                }
                else
                {
                    if (modCheck.WithMod11(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                    {
                        isCheck = true;
                    }

                }

            }

            return isCheck;
        }

        internal bool WithExceptionTwoOrNine(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();

                var aCheckDigitValue = accountNumber.Substring(0, 1);
                var gCheckDigitValue = accountNumber.Substring(6, 1);

                if (aCheckDigitValue != "0" && gCheckDigitValue != "9")
                {
                    int[] newWeight = new int[] { 0, 0, 1, 2, 5, 3, 6, 4, 8, 7, 10, 9, 3, 1 };

                    if (modCheck.WithMod11(sortCode, accountNumber, newWeight).IsValid)
                    {
                        isCheck = true;
                    }

                }
                else if (aCheckDigitValue != "0" && gCheckDigitValue == "9")
                {
                    int[] newWeight = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 8, 7, 10, 9, 3, 1 };
                    if (modCheck.WithMod11(sortCode, accountNumber, newWeight).IsValid)
                    {
                        isCheck = true;
                    }
                }
                else
                {
                    if (modCheck.WithMod11(sortCode, accountNumber, result.FirstOrDefault().Weight).IsValid)
                    {
                        isCheck = true;
                    }
                    else
                    {
                        sortCode = "309634";

                        if (modCheck.WithMod11(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                        {
                            isCheck = true;
                        }
                    }
                }

            }
            return isCheck;
        }

        internal bool WithExceptionSix(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();

                if (modCheck.WithMod11(sortCode, accountNumber, result.FirstOrDefault().Weight).IsValid & modCheck.WithDblal(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                {
                    isCheck = true;
                }
            }

            return isCheck;
        }

        internal bool WithExceptionTwelveOrThirteen(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();

                if (modCheck.WithMod11(sortCode, accountNumber, result.FirstOrDefault().Weight).IsValid)
                {
                    isCheck = true;

                }
                else if (modCheck.WithMod10(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                {
                    isCheck = true;

                }
            }

            return isCheck;
        }

        internal bool WithExceptionFour(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();
                var ghValue = (Convert.ToInt32(accountNumber.Substring(6, 1)) * 10) + Convert.ToInt32(accountNumber.Substring(7, 1));

                var checkResult = modCheck.WithMod11(sortCode, accountNumber, result.LastOrDefault().Weight);
                if (checkResult.IsValid)
                {
                    isCheck = true;

                }
                else
                {
                    var remainder = checkResult.Total % 11;

                    if (remainder != ghValue) continue;
                    isCheck = true;
                }

            }

            return isCheck;
        }

        internal bool WithExceptionThree(string sortCode, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();

                if (modCheck.WithMod11(sortCode, accountNumber, result.FirstOrDefault().Weight).IsValid)
                {
                    var checkDigitC = Convert.ToInt32(accountNumber.Substring(2, 1));

                    if (checkDigitC == 6 || checkDigitC == 9)
                    {
                        isCheck = true;

                    }
                    else if (modCheck.WithDblal(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                    {
                        isCheck = true;
                    }

                }
            }

            return isCheck;
        }

        internal bool WithExceptionOne(string sortCode, string bmdCalculationValue, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();
                var checkResult = modCheck.WithDblal(sortCode, accountNumber, result.LastOrDefault().Weight);

                if (!checkResult.IsValid)
                {

                    checkResult.Total += 27;

                    if (checkResult.Total % 10 == 0)
                    {
                        isCheck = true;
                    }
                }
            }

            return isCheck;
        }

        internal bool WithNoException(string sortCode, string bmdCalculationValue, List<ModulusWeightTable> result, bool isCheck)
        {
            while (!isCheck)
            {
                accountNumber = randomAccountNumber.GenerateAccountNumber();
                switch (bmdCalculationValue)
                {
                    case "MOD11":
                        if (modCheck.WithMod11(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                        {
                            isCheck = true;
                        }

                        break;

                    case "MOD10":
                        if (modCheck.WithMod10(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                        {
                            isCheck = true;
                        }

                        break;

                    case "DBLAL":
                        if (modCheck.WithDblal(sortCode, accountNumber, result.LastOrDefault().Weight).IsValid)
                        {
                            isCheck = true;
                        }

                        break;
                }
            }

            return isCheck;
        }
    }
}
