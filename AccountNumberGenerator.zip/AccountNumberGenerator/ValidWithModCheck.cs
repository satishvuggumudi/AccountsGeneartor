﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountNumberGenerator
{
    public class ValidWithModCheck
    {

        RandomAccountNumber randomAccountNumber = new RandomAccountNumber();

        public CheckResult WithDblal(string sortCode, string accountNumber, int[] weight)
        {
            var checkResult = new CheckResult();

            int[] intArray = randomAccountNumber.SortCodeAccountNumberArray(sortCode, accountNumber);

            int[] length = new int[intArray.Length];

            for (int i = 0; i < intArray.Length; i++)
            {
                length[i] = weight[i] * intArray[i];

                if (length[i] > 9)
                {
                    char[] split = length[i].ToString().ToCharArray();
                    string firstNum = split[0].ToString();
                    string secondNum = split[1].ToString();
                    length[i] = Convert.ToInt32(firstNum) + Convert.ToInt32(secondNum);

                    if (length[i] > 9)
                    {
                        char[] split2 = length[i].ToString().ToCharArray();
                        string firstNum1 = split[0].ToString();
                        string secondNum1 = split[1].ToString();
                        length[i] = Convert.ToInt32(firstNum1) + Convert.ToInt32(secondNum1);
                    }
                }
                checkResult.Total += length[i];

            }
            if (checkResult.Total % 10 == 0)
            {
                checkResult.IsValid = true;
            }
            return checkResult;
        }

        public CheckResult WithMod11(string sortCode, string accountNumber, int[] weight)
        {
            var checkResult = new CheckResult();

            int[] intArray = randomAccountNumber.SortCodeAccountNumberArray(sortCode, accountNumber);

            int[] length = new int[intArray.Length];

            for (int i = 0; i < intArray.Length; i++)
            {
                length[i] = weight[i] * intArray[i];
                checkResult.Total += length[i];
            }
            if (checkResult.Total % 11 == 0)
            {
                checkResult.IsValid = true;
            }
            return checkResult;
        }

        public CheckResult WithMod10(string sortCode, string accountNumber, int[] weight)
        {
            var checkResult = new CheckResult();

            int[] intArray = randomAccountNumber.SortCodeAccountNumberArray(sortCode, accountNumber);
            int[] length = new int[intArray.Length];

            for (int i = 0; i < intArray.Length; i++)
            {
                length[i] = weight[i] * intArray[i];
                checkResult.Total += length[i];
            }
            if (checkResult.Total % 10 == 0)
            {
                checkResult.IsValid = true;
            }
            return checkResult;
        }
    }
}

