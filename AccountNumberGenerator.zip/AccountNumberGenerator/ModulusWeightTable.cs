﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountNumberGenerator
{
    public class ModulusWeightTable
    {
        public string ModulusCheckType { set; get; }

        public int[] Weight { set; get; }

        public int ExceptionValue { set; get; }
    }

    public class CheckResult
    {
        public bool IsValid { get; set; }
        public int Total { get; set; }
    }

    public class Account
    {
        public string AccountNumber { set; get; }
        public string SortCode { set; get; }
        public string BankCode { set; get; }
    }
}
