﻿using System;
using System.Collections.Generic;
using System.Data;

namespace AccountNumberGenerator
{
    public class ReadModulusWeightTable
    {

        ReadExcelData excelData = new ReadExcelData("SortCodeRange.xlsx");

        public List<ModulusWeightTable> ModCalculation(string sortCode)
        {

            var givenSortCode = Convert.ToInt32(sortCode);

            var dt = excelData.ExcelToDataTableUsingExcelDataReader("EISCD");

            var exceptionValue = 0;

            var results = new List<ModulusWeightTable>();

            for (var i = 1; i < dt.Rows.Count; i++)
            {
                var item = new ModulusWeightTable { };

                var range1 = Convert.ToInt32(dt.Rows[i].ItemArray[0]);
                var range2 = Convert.ToInt32(dt.Rows[i].ItemArray[1]);

                if (givenSortCode >= range1 && givenSortCode <= range2)
                {
                    item.ModulusCheckType = dt.Rows[i].ItemArray[2].ToString();
                    item.Weight = GetData(dt.Rows[i]);
                    var x = dt.Rows[i].ItemArray[17];
                    if (!(x is DBNull)) exceptionValue = Convert.ToInt32(x);

                    item.ExceptionValue = exceptionValue;
                    results.Add(item);
                }

            }
            return results;
        }

        private int[] GetData(DataRow row)
        {
            var output = new int[14];
            for (var i = 3; i < 17; i++)
            {
                int.TryParse(row.ItemArray[i]?.ToString(), out int value);
                output[i - 3] = value;
            }

            return output;
        }

        public string SubstituteSortCodeWith(string sortCode)
        {
            //int substituteWithSortcode = Convert.ToInt32(sortCode);
            DataTable dt = excelData.ExcelToDataTableUsingExcelDataReader("Substitute Table");

            for (var i = 0; i < dt.Rows.Count; i++)
            {
                var originalSortCode = dt.Rows[i].ItemArray[0];

                if (sortCode == originalSortCode.ToString())
                {
                    sortCode = (dt.Rows[i].ItemArray[i]).ToString();
                }
            }

            return sortCode;
        }
    }
}
